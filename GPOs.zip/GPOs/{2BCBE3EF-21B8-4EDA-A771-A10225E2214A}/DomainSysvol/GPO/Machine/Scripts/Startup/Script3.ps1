
$drives = Get-WmiObject Win32_LogicalDisk | Where-Object {
	$_.DriveType -eq 3
}


Foreach ($drive in $drives) {
	
	$CdriveStatus = Get-BitLockerVolume -MountPoint $drive.DeviceID

	if ($CdriveStatus.volumeStatus -eq 'FullyDecrypted') {
		C:\Windows\System32\manage-bde.exe -on $drive.DeviceID -recoverypassword -skiphardwaretest
	}
}