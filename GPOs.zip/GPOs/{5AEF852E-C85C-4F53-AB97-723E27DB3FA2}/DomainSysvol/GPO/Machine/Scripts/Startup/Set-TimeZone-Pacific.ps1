
Set-TimeZone -Id "Pacific Standard Time"

<#

Get-TimeZone -ListAvailable

Id                         : Hawaiian Standard Time
DisplayName                : (UTC-10:00) Hawaii
StandardName               : Hawaiian Standard Time
DaylightName               : Hawaiian Daylight Time
BaseUtcOffset              : -10:00:00
SupportsDaylightSavingTime : False

Id                         : Alaskan Standard Time
DisplayName                : (UTC-09:00) Alaska
StandardName               : Alaskan Standard Time
DaylightName               : Alaskan Daylight Time
BaseUtcOffset              : -09:00:00
SupportsDaylightSavingTime : True

Id                         : Pacific Standard Time
DisplayName                : (UTC-08:00) Pacific Time (US & Canada)
StandardName               : Pacific Standard Time
DaylightName               : Pacific Daylight Time
BaseUtcOffset              : -08:00:00
SupportsDaylightSavingTime : True

Id                         : US Mountain Standard Time
DisplayName                : (UTC-07:00) Arizona
StandardName               : US Mountain Standard Time
DaylightName               : US Mountain Daylight Time
BaseUtcOffset              : -07:00:00
SupportsDaylightSavingTime : False

Id                         : Mountain Standard Time
DisplayName                : (UTC-07:00) Mountain Time (US & Canada)
StandardName               : Mountain Standard Time
DaylightName               : Mountain Daylight Time
BaseUtcOffset              : -07:00:00
SupportsDaylightSavingTime : True

Id                         : Central Standard Time
DisplayName                : (UTC-06:00) Central Time (US & Canada)
StandardName               : Central Standard Time
DaylightName               : Central Daylight Time
BaseUtcOffset              : -06:00:00
SupportsDaylightSavingTime : True

Id                         : Eastern Standard Time
DisplayName                : (UTC-05:00) Eastern Time (US & Canada)
StandardName               : Eastern Standard Time
DaylightName               : Eastern Daylight Time
BaseUtcOffset              : -05:00:00
SupportsDaylightSavingTime : True

Id                         : US Eastern Standard Time
DisplayName                : (UTC-05:00) Indiana (East)
StandardName               : US Eastern Standard Time
DaylightName               : US Eastern Daylight Time
BaseUtcOffset              : -05:00:00
SupportsDaylightSavingTime : True

Id                         : Atlantic Standard Time
DisplayName                : (UTC-04:00) Atlantic Time (Canada)
StandardName               : Atlantic Standard Time
DaylightName               : Atlantic Daylight Time
BaseUtcOffset              : -04:00:00
SupportsDaylightSavingTime : True

#>