﻿#  Fix_Java_Exceptions.ps1
#  v1.0 01/29/2020
#  By Chris Amendola
#  amendola@avinc.com
#
#  Looks at lines in the $Exceptions list and checks if they are in $ExceptionsFilePath.  If the are then it skips, if they aren't then it adds.
#
#  Extra line breaks are added during first append to ensure the previous lines don't result in a concatinated line of code
#  The exception is per user, so it can be added to the users login script.


$Exceptions=@"
https://ebsapps.aerovironment.com:4443/
https://docwebtop.aerovironment.com/
https://ebsdev.aerovironment.com:4443/
https://ebsqa.aerovironment.com:4443/
https://ebstst.aerovironment.com:4443/
https://ebsstg.aerovironment.com:4443/
https://ebsuat.aerovironment.com:4443/
https://ebstmp.aerovironment.com:4443/
https://eestst.aerovironment.com:4443/
"@

$ExceptionsFilePath = "C:\users\$($env:USERNAME)\appdata\LocalLow\Sun\Java\Deployment\security\exception.sites"
$ExceptionsPath = "C:\users\$($env:USERNAME)\appdata\LocalLow\Sun\Java\Deployment\security\"
$first_line_add = $true

If(!(test-path $ExceptionsPath))
{
      New-Item -ItemType Directory -Force -Path $ExceptionsPath
} else
{

    #The exception file doesn't like blank lines, it thinks it's at the end of the list if it hits a blank so we want to purge the blank lines.

    (gc "$($ExceptionsFilePath)") | ? {$_.trim() -ne "" } | set-content "$($ExceptionsFilePath)"

}


    $Exceptions.Split([Environment]::NewLine, [StringSplitOptions]::RemoveEmptyEntries) | %{

        if  ((test-path $ExceptionsFilePath) -and (select-string -Path "$($ExceptionsFilePath)" -Pattern "$($_)")) {
          write-host " $_ : already in Exceptions, not adding"
        } else
        {
        write-host "adding $_ to Exceptions"
        out-file -FilePath "$($ExceptionsFilePath)" -Append -Encoding ASCII -InputObject "$_"
        }

    }
